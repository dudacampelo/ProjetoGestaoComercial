package br.com.sgc.swing.service;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import br.com.sgc.swing.dto.ClienteDTO;
import br.com.sgc.swing.dto.ClienteRequestDTO;
import br.com.sgc.swing.dto.LoginRequestDTO;
import br.com.sgc.swing.dto.LoginResponseDTO;
import br.com.sgc.swing.dto.ProdutoDTO;
import br.com.sgc.swing.dto.ProdutoRequestDTO;

import br.com.sgc.swing.dto.VendaRequestDTO;
import br.com.sgc.swing.dto.ItemVendaRequestDTO;

import java.time.LocalDateTime;

import br.com.sgc.swing.dto.RelatorioVendaDTO;

public class ApiService {

    private final HttpClient client = HttpClient.newHttpClient();
    private final Gson gson = new Gson();

    private static final String URL_LOGIN =
            "http://localhost:8080/auth/login";

    private static final String URL_CLIENTES =
            "http://localhost:8080/clientes";
    
    private static final String URL_PRODUTOS =
            "http://localhost:8080/produtos";
    
    private static final String URL_VENDAS =
            "http://localhost:8080/vendas";
    
    private static final String URL_RELATORIOS =
            "http://localhost:8080/relatorios";

    // ==========================
    // LOGIN
    // ==========================
    public LoginResponseDTO login(String usuario, String senha) {

        LoginRequestDTO requestDTO = new LoginRequestDTO();
        requestDTO.setUsername(usuario);
        requestDTO.setSenha(senha);

        String json = gson.toJson(requestDTO);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(URL_LOGIN))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        try {

            HttpResponse<String> response = client.send(
                    request,
                    HttpResponse.BodyHandlers.ofString());

            System.out.println("JSON enviado: " + json);
            System.out.println("Status: " + response.statusCode());
            System.out.println("Resposta: " + response.body());

            if (response.statusCode() == 200) {

                return gson.fromJson(response.body(), LoginResponseDTO.class);

            }

        } catch (IOException | InterruptedException e) {

            e.printStackTrace();

        }

        return null;
    }

    // ==========================
    // LISTAR CLIENTES
    // ==========================
    public List<ClienteDTO> listarClientes(String token) {

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(URL_CLIENTES))
                .header("Authorization", "Bearer " + token)
                .GET()
                .build();

        try {

            HttpResponse<String> response = client.send(
                    request,
                    HttpResponse.BodyHandlers.ofString());

            System.out.println("Status Clientes: " + response.statusCode());
            System.out.println("Resposta Clientes: " + response.body());

            if (response.statusCode() == 200) {

                Type tipoLista = new TypeToken<List<ClienteDTO>>() {
                }.getType();

                return gson.fromJson(response.body(), tipoLista);

            }

        } catch (IOException | InterruptedException e) {

            e.printStackTrace();

        }

        return null;
    }
    public boolean salvarCliente(ClienteRequestDTO cliente, String token) {

        String json = gson.toJson(cliente);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(URL_CLIENTES))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + token)
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        try {

            HttpResponse<String> response = client.send(
                    request,
                    HttpResponse.BodyHandlers.ofString());

            System.out.println("Status Salvar: " + response.statusCode());
            System.out.println("Resposta Salvar: " + response.body());

            return response.statusCode() == 201;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }
    public boolean editarCliente(Long id, ClienteDTO cliente, String token) {

        String json = gson.toJson(cliente);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(URL_CLIENTES + "/" + id))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + token)
                .PUT(HttpRequest.BodyPublishers.ofString(json))
                .build();

        try {

            HttpResponse<String> response = client.send(
                    request,
                    HttpResponse.BodyHandlers.ofString());

            System.out.println("Status Editar: " + response.statusCode());
            System.out.println(response.body());

            return response.statusCode() == 200;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public boolean excluirCliente(Long id, String token) {

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(URL_CLIENTES + "/" + id))
                .header("Authorization", "Bearer " + token)
                .DELETE()
                .build();

        try {

            HttpResponse<String> response = client.send(
                    request,
                    HttpResponse.BodyHandlers.ofString());

            System.out.println("Status Excluir: " + response.statusCode());

            return response.statusCode() == 204;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }
 // ==========================
 // LISTAR PRODUTOS
 // ==========================
 public List<ProdutoDTO> listarProdutos(String token) {

     HttpRequest request = HttpRequest.newBuilder()
             .uri(URI.create(URL_PRODUTOS))
             .header("Authorization", "Bearer " + token)
             .GET()
             .build();

     try {

         HttpResponse<String> response = client.send(
                 request,
                 HttpResponse.BodyHandlers.ofString());

         System.out.println("Status Produtos: " + response.statusCode());
         System.out.println("Resposta Produtos: " + response.body());

         if (response.statusCode() == 200) {

             Type tipoLista = new TypeToken<List<ProdutoDTO>>() {}.getType();

             return gson.fromJson(response.body(), tipoLista);

         }

     } catch (IOException | InterruptedException e) {

         e.printStackTrace();

     }

     return null;
 }
 public boolean salvarProduto(ProdutoRequestDTO produto, String token) {

	    String json = gson.toJson(produto);

	    HttpRequest request = HttpRequest.newBuilder()
	            .uri(URI.create(URL_PRODUTOS))
	            .header("Content-Type", "application/json")
	            .header("Authorization", "Bearer " + token)
	            .POST(HttpRequest.BodyPublishers.ofString(json))
	            .build();

	    try {

	        HttpResponse<String> response = client.send(
	                request,
	                HttpResponse.BodyHandlers.ofString());

	        System.out.println("Status Salvar Produto: " + response.statusCode());
	        System.out.println("Resposta: " + response.body());

	        return response.statusCode() == 201;

	    } catch (Exception e) {

	        e.printStackTrace();

	    }

	    return false;
	}
 public boolean editarProduto(Long id, ProdutoDTO produto, String token) {

	    String json = gson.toJson(produto);

	    HttpRequest request = HttpRequest.newBuilder()
	            .uri(URI.create(URL_PRODUTOS + "/" + id))
	            .header("Content-Type", "application/json")
	            .header("Authorization", "Bearer " + token)
	            .PUT(HttpRequest.BodyPublishers.ofString(json))
	            .build();

	    try {

	        HttpResponse<String> response = client.send(
	                request,
	                HttpResponse.BodyHandlers.ofString());

	        System.out.println("Status Editar Produto: " + response.statusCode());
	        System.out.println(response.body());

	        return response.statusCode() == 200;

	    } catch (Exception e) {

	        e.printStackTrace();

	    }

	    return false;
	}
 public boolean excluirProduto(Long id, String token) {

	    HttpRequest request = HttpRequest.newBuilder()
	            .uri(URI.create(URL_PRODUTOS + "/" + id))
	            .header("Authorization", "Bearer " + token)
	            .DELETE()
	            .build();

	    try {

	        HttpResponse<String> response = client.send(
	                request,
	                HttpResponse.BodyHandlers.ofString());

	        System.out.println("Status Excluir Produto: " + response.statusCode());

	        return response.statusCode() == 204;

	    } catch (Exception e) {

	        e.printStackTrace();

	    }

	    return false;
	}
 public boolean registrarVenda(VendaRequestDTO venda, String token) {

	    String json = gson.toJson(venda);

	    HttpRequest request = HttpRequest.newBuilder()
	            .uri(URI.create(URL_VENDAS))
	            .header("Content-Type", "application/json")
	            .header("Authorization", "Bearer " + token)
	            .POST(HttpRequest.BodyPublishers.ofString(json))
	            .build();

	    try {

	        HttpResponse<String> response = client.send(
	                request,
	                HttpResponse.BodyHandlers.ofString());

	        System.out.println("Status Venda: " + response.statusCode());
	        System.out.println("Resposta Venda: " + response.body());

	        return response.statusCode() == 201;

	    } catch (Exception e) {

	        e.printStackTrace();

	    }

	    return false;
	}
 public List<RelatorioVendaDTO> relatorioPorCliente(Long clienteId, String token) {

	    HttpRequest request = HttpRequest.newBuilder()
	            .uri(URI.create(URL_RELATORIOS + "/cliente/" + clienteId))
	            .header("Authorization", "Bearer " + token)
	            .GET()
	            .build();

	    try {

	        HttpResponse<String> response = client.send(
	                request,
	                HttpResponse.BodyHandlers.ofString());

	        System.out.println("Status Relatório: " + response.statusCode());
	        System.out.println("Resposta Relatório: " + response.body());

	        if (response.statusCode() == 200) {

	            Type tipoLista =
	                    new TypeToken<List<RelatorioVendaDTO>>() {}.getType();

	            return gson.fromJson(response.body(), tipoLista);

	        }

	    } catch (Exception e) {

	        e.printStackTrace();

	    }

	    return null;
	}
}