package br.com.sgc.swing.telas;

import java.util.List;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import br.com.sgc.swing.dto.RelatorioVendaDTO;
import br.com.sgc.swing.service.ApiService;

public class TelaRelatorios extends JFrame {

    private JPanel contentPane;

    private JTextField txtCliente;

    private JTable tabela;

    private String token;

    public TelaRelatorios(String token) {

        this.token = token;

        setTitle("Relatório de Vendas");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100,100,700,450);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5,5,5,5));
        contentPane.setLayout(null);

        setContentPane(contentPane);

        JLabel lblCliente = new JLabel("ID Cliente");

        lblCliente.setBounds(20,20,100,20);

        contentPane.add(lblCliente);

        txtCliente = new JTextField();

        txtCliente.setBounds(110,20,100,22);

        contentPane.add(txtCliente);

        JButton btnPesquisar = new JButton("Pesquisar");

        btnPesquisar.setBounds(240,20,120,25);

        contentPane.add(btnPesquisar);

        JScrollPane scroll = new JScrollPane();

        scroll.setBounds(20,70,640,300);

        contentPane.add(scroll);

        tabela = new JTable();

        scroll.setViewportView(tabela);

        btnPesquisar.addActionListener(e -> carregarRelatorio());

    }

    private void carregarRelatorio() {

        ApiService api = new ApiService();

        List<RelatorioVendaDTO> lista =
                api.relatorioPorCliente(
                        Long.parseLong(txtCliente.getText()),
                        token);

        DefaultTableModel modelo = new DefaultTableModel();

        modelo.addColumn("ID");

        modelo.addColumn("Cliente");

        modelo.addColumn("Usuário");

        modelo.addColumn("Data");

        modelo.addColumn("Valor");

        if(lista != null){

            for(RelatorioVendaDTO venda : lista){

                modelo.addRow(new Object[]{

                        venda.getId(),

                        venda.getNomeCliente(),

                        venda.getUsernameUsuario(),

                        venda.getData(),

                        venda.getValorTotal()

                });

            }

        }

        tabela.setModel(modelo);

    }

}