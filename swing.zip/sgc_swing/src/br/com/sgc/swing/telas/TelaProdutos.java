package br.com.sgc.swing.telas;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import java.util.List;

import javax.swing.table.DefaultTableModel;

import br.com.sgc.swing.dto.ProdutoDTO;
import br.com.sgc.swing.service.ApiService;

import java.math.BigDecimal;
import javax.swing.JOptionPane;

import br.com.sgc.swing.dto.ProdutoRequestDTO;


public class TelaProdutos extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    private JTextField txtNome;
    private JTextField txtDescricao;
    private JTextField txtPreco;
    private JTextField txtEstoque;
    private JTextField txtEstoqueMinimo;

    private JTable tblProdutos;
    
    private String token;
    
    private Long idSelecionado = null;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                TelaProdutos frame = new TelaProdutos("");
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public TelaProdutos(String token) {

        this.token = token;
    	

        setTitle("Cadastro de Produtos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 650, 450);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblNome = new JLabel("Nome");
        lblNome.setBounds(10, 15, 80, 20);
        contentPane.add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(120, 15, 180, 22);
        contentPane.add(txtNome);

        JLabel lblDescricao = new JLabel("Descrição");
        lblDescricao.setBounds(10, 50, 80, 20);
        contentPane.add(lblDescricao);

        txtDescricao = new JTextField();
        txtDescricao.setBounds(120, 50, 180, 22);
        contentPane.add(txtDescricao);

        JLabel lblPreco = new JLabel("Preço");
        lblPreco.setBounds(10, 85, 80, 20);
        contentPane.add(lblPreco);

        txtPreco = new JTextField();
        txtPreco.setBounds(120, 85, 180, 22);
        contentPane.add(txtPreco);

        JLabel lblEstoque = new JLabel("Estoque");
        lblEstoque.setBounds(10, 120, 80, 20);
        contentPane.add(lblEstoque);

        txtEstoque = new JTextField();
        txtEstoque.setBounds(120, 120, 180, 22);
        contentPane.add(txtEstoque);

        JLabel lblEstoqueMinimo = new JLabel("Estoque Mínimo");
        lblEstoqueMinimo.setBounds(10, 155, 100, 20);
        contentPane.add(lblEstoqueMinimo);

        txtEstoqueMinimo = new JTextField();
        txtEstoqueMinimo.setBounds(120, 155, 180, 22);
        contentPane.add(txtEstoqueMinimo);

        JButton btnNovo = new JButton("Novo");
        btnNovo.setBounds(350, 20, 120, 25);
        contentPane.add(btnNovo);

        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.setBounds(350, 60, 120, 25);
        contentPane.add(btnSalvar);
        btnSalvar.addActionListener(e -> {

            ProdutoRequestDTO produto = new ProdutoRequestDTO();

            produto.setNome(txtNome.getText());
            produto.setDescricao(txtDescricao.getText());
            produto.setPreco(new BigDecimal(txtPreco.getText()));
            produto.setEstoque(Integer.parseInt(txtEstoque.getText()));
            produto.setEstoqueMinimo(Integer.parseInt(txtEstoqueMinimo.getText()));

            ApiService api = new ApiService();

            if (api.salvarProduto(produto, token)) {

                JOptionPane.showMessageDialog(null,
                        "Produto salvo com sucesso!");

                carregarProdutos();

            } else {

                JOptionPane.showMessageDialog(null,
                        "Erro ao salvar produto.");

            }

        });

        JButton btnEditar = new JButton("Editar");
        btnEditar.setBounds(350, 100, 120, 25);
        contentPane.add(btnEditar);
        btnEditar.addActionListener(e -> {

            if (idSelecionado == null) {

                JOptionPane.showMessageDialog(null,
                        "Selecione um produto.");

                return;

            }

            ProdutoDTO produto = new ProdutoDTO();

            produto.setNome(txtNome.getText());
            produto.setDescricao(txtDescricao.getText());
            produto.setPreco(new BigDecimal(txtPreco.getText()));
            produto.setEstoque(Integer.parseInt(txtEstoque.getText()));
            produto.setEstoqueMinimo(Integer.parseInt(txtEstoqueMinimo.getText()));

            ApiService api = new ApiService();

            if (api.editarProduto(idSelecionado, produto, token)) {

                JOptionPane.showMessageDialog(null,
                        "Produto atualizado com sucesso!");

                carregarProdutos();

            } else {

                JOptionPane.showMessageDialog(null,
                        "Erro ao atualizar produto.");

            }

        });

        JButton btnExcluir = new JButton("Excluir");
        btnExcluir.setBounds(350, 140, 120, 25);
        contentPane.add(btnExcluir);
        btnExcluir.addActionListener(e -> {

            if (idSelecionado == null) {

                JOptionPane.showMessageDialog(null,
                        "Selecione um produto.");

                return;

            }

            int opcao = JOptionPane.showConfirmDialog(
                    null,
                    "Deseja realmente excluir este produto?",
                    "Confirmação",
                    JOptionPane.YES_NO_OPTION);

            if (opcao == JOptionPane.YES_OPTION) {

                ApiService api = new ApiService();

                if (api.excluirProduto(idSelecionado, token)) {

                    JOptionPane.showMessageDialog(null,
                            "Produto excluído com sucesso!");

                    carregarProdutos();

                    txtNome.setText("");
                    txtDescricao.setText("");
                    txtPreco.setText("");
                    txtEstoque.setText("");
                    txtEstoqueMinimo.setText("");

                    idSelecionado = null;

                } else {

                    JOptionPane.showMessageDialog(null,
                            "Erro ao excluir produto.");

                }

            }

        });

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 210, 610, 180);
        contentPane.add(scrollPane);

        tblProdutos = new JTable();
        scrollPane.setViewportView(tblProdutos);
        
        tblProdutos.getSelectionModel().addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting() && tblProdutos.getSelectedRow() != -1) {

                int linha = tblProdutos.getSelectedRow();

                idSelecionado = Long.parseLong(
                        tblProdutos.getValueAt(linha, 0).toString());

                txtNome.setText(tblProdutos.getValueAt(linha, 1).toString());
                txtDescricao.setText(tblProdutos.getValueAt(linha, 2).toString());
                txtPreco.setText(tblProdutos.getValueAt(linha, 3).toString());
                txtEstoque.setText(tblProdutos.getValueAt(linha, 4).toString());
                txtEstoqueMinimo.setText(tblProdutos.getValueAt(linha, 5).toString());

            }

        });
        
        carregarProdutos();
    }
    private void carregarProdutos() {

        ApiService api = new ApiService();

        List<ProdutoDTO> lista = api.listarProdutos(token);

        DefaultTableModel modelo = new DefaultTableModel();

        modelo.addColumn("ID");
        modelo.addColumn("Nome");
        modelo.addColumn("Descrição");
        modelo.addColumn("Preço");
        modelo.addColumn("Estoque");
        modelo.addColumn("Estoque Mínimo");

        if (lista != null) {

            for (ProdutoDTO produto : lista) {

                modelo.addRow(new Object[] {

                        produto.getId(),
                        produto.getNome(),
                        produto.getDescricao(),
                        produto.getPreco(),
                        produto.getEstoque(),
                        produto.getEstoqueMinimo()

                });

            }

        }

        tblProdutos.setModel(modelo);

    }
}
