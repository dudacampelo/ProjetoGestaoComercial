package br.com.sgc.swing.telas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.sgc.swing.dto.ItemVendaRequestDTO;
import br.com.sgc.swing.dto.VendaRequestDTO;
import br.com.sgc.swing.service.ApiService;

public class TelaVendas extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    private JTextField txtCliente;
    private JTextField txtProduto;
    private JTextField txtQuantidade;

    private String token;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                TelaVendas frame = new TelaVendas("");
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public TelaVendas(String token) {

        this.token = token;

        setTitle("Registro de Vendas");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 500, 250);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5,5,5,5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblCliente = new JLabel("ID Cliente");
        lblCliente.setBounds(20,20,100,20);
        contentPane.add(lblCliente);

        txtCliente = new JTextField();
        txtCliente.setBounds(130,20,120,22);
        contentPane.add(txtCliente);

        JLabel lblProduto = new JLabel("ID Produto");
        lblProduto.setBounds(20,60,100,20);
        contentPane.add(lblProduto);

        txtProduto = new JTextField();
        txtProduto.setBounds(130,60,120,22);
        contentPane.add(txtProduto);

        JLabel lblQuantidade = new JLabel("Quantidade");
        lblQuantidade.setBounds(20,100,100,20);
        contentPane.add(lblQuantidade);

        txtQuantidade = new JTextField();
        txtQuantidade.setBounds(130,100,120,22);
        contentPane.add(txtQuantidade);

        JButton btnSalvar = new JButton("Registrar Venda");
        btnSalvar.setBounds(130,150,180,30);
        contentPane.add(btnSalvar);
        btnSalvar.addActionListener(e -> {

            try {

                VendaRequestDTO venda = new VendaRequestDTO();

                venda.setClienteId(
                        Long.parseLong(txtCliente.getText()));

                ItemVendaRequestDTO item = new ItemVendaRequestDTO();

                item.setProdutoId(
                        Long.parseLong(txtProduto.getText()));

                item.setQuantidade(
                        Integer.parseInt(txtQuantidade.getText()));

                List<ItemVendaRequestDTO> itens = new ArrayList<>();

                itens.add(item);

                venda.setItens(itens);

                ApiService api = new ApiService();

                if (api.registrarVenda(venda, token)) {

                    JOptionPane.showMessageDialog(null,
                            "Venda registrada com sucesso!");

                    txtCliente.setText("");
                    txtProduto.setText("");
                    txtQuantidade.setText("");

                } else {

                    JOptionPane.showMessageDialog(null,
                            "Erro ao registrar venda.");

                }

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(null,
                        "Preencha os campos corretamente.");

            }

        });
    }
}
