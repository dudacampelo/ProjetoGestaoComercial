package br.com.sgc.swing.telas;

import java.awt.EventQueue;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import br.com.sgc.swing.dto.ClienteDTO;
import br.com.sgc.swing.dto.ClienteRequestDTO;
import br.com.sgc.swing.service.ApiService;

public class TelaClientes extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNome;
	private JTextField txtCpf;
	private JTextField txtTelefone;
	private JTextField txtEmail;
	private JTextField txtEndereco;
	
	private JTable tblClientes;
	
	private String token;
	
	private Long idSelecionado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaClientes frame = new TelaClientes("");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaClientes(String token) {

	    this.token = token;
	    setTitle("Cadastro de Clientes");
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    setBounds(100, 100, 650, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setBounds(10, 15, 80, 20);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("CPF");
		lblNewLabel_1.setBounds(10, 50, 80, 20);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Telefone");
		lblNewLabel_2.setBounds(10, 85, 80, 20);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Email");
		lblNewLabel_3.setBounds(10, 120, 80, 20);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblEndereco = new JLabel("Endereço");
		lblEndereco.setBounds(10, 155, 100, 20);
		contentPane.add(lblEndereco);
		
		txtNome = new JTextField();
		txtNome.setBounds(120, 15, 180, 22);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		txtCpf = new JTextField();
		txtCpf.setBounds(120, 50, 180, 22);
		contentPane.add(txtCpf);
		txtCpf.setColumns(10);
		
		txtTelefone = new JTextField();
		txtTelefone.setBounds(120, 85, 180, 22);
		contentPane.add(txtTelefone);
		txtTelefone.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setBounds(120, 120, 180, 22);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);
		
		txtEndereco = new JTextField();
		txtEndereco.setBounds(120, 155, 180, 22);
		contentPane.add(txtEndereco);
		txtEndereco.setColumns(10);
		
		JButton btnNewButton = new JButton("Novo");
		btnNewButton.setBounds(350,20,120,25);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(e -> {

		    txtNome.setText("");
		    txtCpf.setText("");
		    txtTelefone.setText("");
		    txtEmail.setText("");
		    txtEndereco.setText("");

		    idSelecionado = null;

		    tblClientes.clearSelection();

		    txtNome.requestFocus();

		});
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(350,60,120,25);
		contentPane.add(btnSalvar);
		btnSalvar.addActionListener(e -> {
			String nome = txtNome.getText();
			String cpf = txtCpf.getText();
			String telefone = txtTelefone.getText();
			String email = txtEmail.getText();
			String endereco = txtEndereco.getText();
			
			ClienteRequestDTO cliente = new ClienteRequestDTO();

			cliente.setNome(nome);
			cliente.setCpf(cpf);
			cliente.setTelefone(telefone);
			cliente.setEmail(email);
			cliente.setEndereco(endereco);
			
			ApiService api = new ApiService();

			boolean salvou = api.salvarCliente(cliente, token);
			
			if (salvou) {

			    javax.swing.JOptionPane.showMessageDialog(this,
			            "Cliente cadastrado com sucesso!");
			    carregarClientes();

			    txtNome.setText("");
			    txtCpf.setText("");
			    txtTelefone.setText("");
			    txtEmail.setText("");
			    txtEndereco.setText("");

			} else {

			    javax.swing.JOptionPane.showMessageDialog(this,
			            "Erro ao cadastrar cliente.");

			}
		});
	
		JButton btnNewButton_2 = new JButton("Editar");
		btnNewButton_2.setBounds(350,100,120,25);
		contentPane.add(btnNewButton_2);
		btnNewButton_2.addActionListener(e -> {

		    int linha = tblClientes.getSelectedRow();

		    if (linha == -1) {
		        javax.swing.JOptionPane.showMessageDialog(null,
		                "Selecione um cliente.");
		        return;
		    }

		    ClienteDTO cliente = new ClienteDTO();

		    Long id = Long.parseLong(
		            tblClientes.getValueAt(linha, 0).toString());

		    cliente.setNome(txtNome.getText());
		    cliente.setCpf(txtCpf.getText());
		    cliente.setTelefone(txtTelefone.getText());
		    cliente.setEmail(txtEmail.getText());
		    cliente.setEndereco(txtEndereco.getText());

		    ApiService api = new ApiService();

		    if (api.editarCliente(id, cliente, token)) {

		        javax.swing.JOptionPane.showMessageDialog(null,
		                "Cliente atualizado!");

		        carregarClientes();

		    } else {

		        javax.swing.JOptionPane.showMessageDialog(null,
		                "Erro ao atualizar.");

		    }

		});
		
		JButton btnNewButton_3 = new JButton("Excluir");
		btnNewButton_3.setBounds(350,140,120,25);
		contentPane.add(btnNewButton_3);
		btnNewButton_3.addActionListener(e -> {

		    int linha = tblClientes.getSelectedRow();

		    if (linha == -1) {

		        javax.swing.JOptionPane.showMessageDialog(null,
		                "Selecione um cliente.");

		        return;
		    }

		    int resposta = javax.swing.JOptionPane.showConfirmDialog(
		            null,
		            "Deseja realmente excluir este cliente?",
		            "Confirmação",
		            javax.swing.JOptionPane.YES_NO_OPTION);

		    if (resposta == javax.swing.JOptionPane.YES_OPTION) {

		        Long id = Long.parseLong(
		                tblClientes.getValueAt(linha, 0).toString());

		        ApiService api = new ApiService();

		        if (api.excluirCliente(id, token)) {

		            javax.swing.JOptionPane.showMessageDialog(null,
		                    "Cliente excluído com sucesso!");

		            carregarClientes();

		        } else {

		            javax.swing.JOptionPane.showMessageDialog(null,
		                    "Erro ao excluir.");

		        }

		    }

		});
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10,210,610,180);
		contentPane.add(scrollPane);

		tblClientes = new JTable();
		scrollPane.setViewportView(tblClientes);
		
		carregarClientes();
		
		tblClientes.getSelectionModel().addListSelectionListener(e -> {

		    if (!e.getValueIsAdjusting()) {

		        int linha = tblClientes.getSelectedRow();
		        
		        if (linha >= 0) {
		        	
		        	idSelecionado = Long.parseLong(
		        	        tblClientes.getValueAt(linha, 0).toString());

		            txtNome.setText(tblClientes.getValueAt(linha, 1).toString());
		            txtCpf.setText(tblClientes.getValueAt(linha, 2).toString());
		            txtTelefone.setText(tblClientes.getValueAt(linha, 3).toString());
		            txtEmail.setText(tblClientes.getValueAt(linha, 4).toString());
		            txtEndereco.setText(tblClientes.getValueAt(linha, 5).toString());

		        }

		    }

		});

	}
	private void carregarClientes() {

	    ApiService api = new ApiService();

	    List<ClienteDTO> lista = api.listarClientes(token);
	    System.out.println("Quantidade: " + lista.size());

	    DefaultTableModel modelo = new DefaultTableModel();

	    modelo.addColumn("ID");
	    modelo.addColumn("Nome");
	    modelo.addColumn("CPF");
	    modelo.addColumn("Telefone");
	    modelo.addColumn("Email");
	    modelo.addColumn("Endereço");

	    if (lista != null) {

	        for (ClienteDTO cliente : lista) {
	        	
	        	System.out.println(cliente.getNome());

	        	modelo.addRow(new Object[] {

	        	        cliente.getId(),
	        	        cliente.getNome(),
	        	        cliente.getCpf(),
	        	        cliente.getTelefone(),
	        	        cliente.getEmail(),
	        	        cliente.getEndereco()

	        	});

	        }

	    }

	    tblClientes.setModel(modelo);

	}
}
