package br.com.sgc.swing.telas;
import br.com.sgc.swing.dto.LoginResponseDTO;
import br.com.sgc.swing.service.ApiService;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TelaLogin extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtUsuario;
	private JPasswordField txtSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaLogin frame = new TelaLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaLogin() {
		setTitle("Sistema de Gerenciamento Comercial");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 555, 333);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtUsuario = new JTextField();
		txtUsuario.setBounds(81, 42, 96, 20);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Usuário");
		lblNewLabel.setBounds(23, 45, 48, 14);
		contentPane.add(lblNewLabel);
		
		JLabel NewLabel = new JLabel("Senha:");
		NewLabel.setBounds(23, 76, 250, 14);
		contentPane.add(NewLabel);
		
		txtSenha = new JPasswordField();
		txtSenha.setBounds(80, 73, 96, 20);
		contentPane.add(txtSenha);
		
		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.setBounds(56, 109, 63, 23);
		contentPane.add(btnEntrar);
		btnEntrar.addActionListener(new java.awt.event.ActionListener() {

		    @Override
		    public void actionPerformed(java.awt.event.ActionEvent e) {

		    	String usuario = txtUsuario.getText();
		    	String senha = new String(txtSenha.getPassword());

		    	ApiService apiService = new ApiService();

		    	LoginResponseDTO resposta = apiService.login(usuario, senha);

		    	if (resposta != null) {

		    		TelaPrincipal tela = new TelaPrincipal(resposta.getToken());
		    		tela.setVisible(true);

		    		dispose();

		    	} else {

		    	    JOptionPane.showMessageDialog(null,
		    	            "Usuário ou senha inválidos!");

		    	}

		    }

		});
	}
}
