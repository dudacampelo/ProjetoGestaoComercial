package br.com.sgc.swing.telas;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class TelaPrincipal extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    // Guarda o token do usuário logado
    private String token;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    TelaPrincipal frame = new TelaPrincipal("");
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    // Construtor recebendo o token
    public TelaPrincipal(String token) {

        this.token = token;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Sistema de Gerenciamento Comercial");
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 18));
        lblNewLabel.setBounds(52, 10, 332, 22);
        contentPane.add(lblNewLabel);

        JButton btnClientes = new JButton("Clientes");
        btnClientes.setBounds(10, 63, 88, 22);
        contentPane.add(btnClientes);

        btnClientes.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                TelaClientes tela = new TelaClientes(token);
                tela.setVisible(true);

            }
        });

        JButton btnProdutos = new JButton("Produtos");
        btnProdutos.setBounds(10, 96, 88, 22);
        contentPane.add(btnProdutos);
        btnProdutos.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                TelaProdutos tela = new TelaProdutos(token);
                tela.setVisible(true);

            }
        });

        JButton btnVendas = new JButton("Vendas");
        btnVendas.addActionListener(e -> {

            TelaVendas tela = new TelaVendas(token);
            tela.setVisible(true);

        });
        btnVendas.setBounds(10, 131, 88, 22);
        contentPane.add(btnVendas);

        JButton btnRelatorios = new JButton("Relatórios");
        btnRelatorios.setBounds(10, 164, 88, 22);
        contentPane.add(btnRelatorios);
        btnRelatorios.addActionListener(e -> {

            TelaRelatorios tela = new TelaRelatorios(token);

            tela.setVisible(true);

        });

        JButton btnSair = new JButton("Sair");
        btnSair.setBounds(10, 200, 88, 22);
        contentPane.add(btnSair);
        btnSair.addActionListener(e -> {

            dispose();

            TelaLogin tela = new TelaLogin();
            tela.setVisible(true);

        });
    }
}